require "lua/init"

function InitGlobalManager()
	g_WaitingController = WaitingController.create()
	g_AudioController = AudioController.create()
	g_PopupController = PopupController.create()
	g_MsgBoxController = MsgBoxController.create()
	g_ToastController = ToastController.create()
	g_noticeBoardController = NoticeBoardController.create()
	g_UIController = UIControllerNew.create()
	g_redDotController =  RedDotController.create()	
	g_UIMsgDispacher = UIMsgDispacher.create()
	g_ServerTimeDispacher = ServerTimeDispacher.create()
	-- g_LoadingWnd = LoadingWnd.create()
	g_WeiXinData = WeiXinData.new()
	if lua_getTargetQuDao() == hg.QuoDaoAPIType.MJOY then
		--g_SDKInterface_MJOY_Wrapper = SDKInterface_MJOY_Wrapper.create()
		g_SDKCocosCppImpl_MJOY_lua = SDKCocosCppImpl_MJOY_lua.create() 
	end 
	g_SDKInterface_MJOY_Wrapper = SDKInterface_MJOY_Wrapper.create()

	g_Lang = require("lua.lang.Lang")
	g_ActionHelper = require("lua.common.ActionHelper")
	g_AssetsDownloader = AssetsDownloader:getInstance()
	g_AssetsDownloader:init("project.manifest",cc.FileUtils:getInstance():getWritablePath().."asssetdownloader")
	g_AssetsDownloader:update()
	package.path = cc.FileUtils:getInstance():getWritablePath().."asssetdownloader/?.lua"..";"..package.path



	-- print("package "..package.path)


		-- 注册通知
	--[[
推送时间	推送内容
11:00	午餐吃得好，下午没烦恼，快来领体力啦！
11:55	一大波敌人正在靠近，快做好防守准备，不要被反扑！
17:00	晚餐做老饕，吃完还打包，快来领体力啦！
21:00	夜宵省不了，安心睡好觉，快来领体力啦！

	]]
	-- g_AudioController:PushNotificationByLua(GetLuaLocalization("LocalizeAuto_start_1276"),11,0,"tili01")
	-- -- g_AudioController:PushNotificationByLua(GetLuaLocalization("LocalizeAuto_start_1277"),11,55,"tili02")
	-- g_AudioController:PushNotificationByLua(GetLuaLocalization("LocalizeAuto_start_1278"),17,0,"tili03")
	-- g_AudioController:PushNotificationByLua(GetLuaLocalization("LocalizeAuto_start_1279"),21,0,"tili04")
	-- 5 000 000 000
end 


function startMain()
    --deleteHead()

	math.randomseed(os.time())
	g_ConfigLua = ConfigData.new()
	
	gf_configLoader = GFConfigLoader.new()
	gf_global = GFGlobal.new()
	gf_timer = GFTimer.new()
	gf_netData = GFNetData.new()
	gf_userData = GFUserData.new()
	gf_buryingPoint = GFBuryingPointData.new()
	
	-- gf_netConnection = NetConnection.new()

	NetProtocol:Init()	
	GameData.Init()
	ToastControllerRequire.Init()
	MsgBoxControllerRequire.Init()
	initServerLog()
	InitGlobalManager()

	local table1 = {
		[1] = {test=1,test2=3,},
		[2] = {test=2,test2=4,},
	}
--	saveWritableFile("gameList2",table1)
	--local table2 = readWritableFile("gameList2")
	--print("serialize table2",serialize(table2))

	--
	g_MainWnd = MainWnd.create()

	return g_MainWnd
end
